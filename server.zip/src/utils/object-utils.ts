export const deepCopy = (arr) => JSON.parse(JSON.stringify(arr));
