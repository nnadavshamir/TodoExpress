import { TodoStatusQueryParam } from './todo-status-request';

export interface TodoSizeQueryParams {
  status: TodoStatusQueryParam;
}
