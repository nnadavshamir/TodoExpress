export interface DeleteTodoQueryParams {
  id: number;
}
