export interface CreateTodoRequest {
  title: string;
  content: string;
  dueDate: number;
}
